# Imports
import cv2
import mediapipe as mp
import math
import time
import random
from datetime import timedelta, datetime, date
import csv
import os
import platform
import threading
import tkinter as tk
from tkinter import messagebox, ttk, simpledialog, filedialog
import webbrowser
from PIL import Image, ImageTk
import json
import pyttsx3
import matplotlib.pyplot as plt
from fpdf import FPDF

#Config
BREAK_INTERVAL_MINUTES = 5
BREAK_DURATION_SECONDS = 60
SNAPSHOT_FOLDER = "snapshots"
QUOTE_FILE = "data/quotes.json"
LOG_FILE = "focuscam_session_log.csv"
REPORT_FOLDER = "report_output"

os.makedirs(SNAPSHOT_FOLDER, exist_ok=True)
os.makedirs("data", exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)

# --- Load or create quotes ---
def load_quotes():
    default_quotes = {
        "motivational": [
            "Stay focused. Stay determined. Greatness is built in silence.",
            "You're investing in your future with every minute.",
            "Every minute you focus now pays off tomorrow.",
            "Your future self is already proud of you.",
            "The grind is tough, but so are you."
        ],
        "punishing": [
            "Discipline is doing it even when no one is watching.",
            "Excuses do not get degrees.",
            "Losing focus is easy. Winning takes consistency.",
            "Breaks are earned, not stolen.",
            "Each distraction is a step away from your goals."
        ]
    }
    if not os.path.exists(QUOTE_FILE):
        with open(QUOTE_FILE, 'w') as f:
            json.dump(default_quotes, f)
    with open(QUOTE_FILE) as f:
        return json.load(f)

def save_quotes(quotes):
    with open(QUOTE_FILE, 'w') as f:
        json.dump(quotes, f, indent=4)

quotes = load_quotes()

# --- Utils ---
def play_alert_sound():
    if platform.system() == "Windows":
        import winsound
        winsound.Beep(1000, 500)

def speak(text):
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

def get_quote(focus_percent: int):
    if focus_percent >= 90:
        return random.choice(quotes["motivational"] + ["You're doing amazing! Keep it up!"])
    elif focus_percent >= 70:
        return "Good job! But you can do even better!"
    else:
        return random.choice(quotes["punishing"] + ["Let's refocus and push forward!"])

def calculate_head_pitch(nose, chin):
    pitch = math.degrees(math.atan2(chin.y - nose.y, 0.1))
    return pitch

def save_snapshot(frame):
    filename = os.path.join(SNAPSHOT_FOLDER, f"distraction_{int(time.time())}.jpg")
    cv2.imwrite(filename, frame)

# --- Report Generator ---
def generate_pdf_report():
    today = str(date.today())
    focused = distracted = total = 0
    with open(LOG_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if today in row['timestamp']:
                focused += int(row['focused_time'])
                distracted += int(row['distracted_time'])
    total = focused + distracted
    percent = int((focused / total) * 100) if total else 0

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=14)
    pdf.cell(200, 10, txt="FocusCam Daily Report", ln=True, align='C')
    pdf.ln(10)
    pdf.cell(200, 10, txt=f"Date: {today}", ln=True)
    pdf.cell(200, 10, txt=f"Focused Time: {timedelta(seconds=focused)}", ln=True)
    pdf.cell(200, 10, txt=f"Distracted Time: {timedelta(seconds=distracted)}", ln=True)
    pdf.cell(200, 10, txt=f"Focus Percent: {percent}%", ln=True)
    pdf.output(os.path.join(REPORT_FOLDER, f"report_{today}.pdf"))
    messagebox.showinfo("PDF Generated", f"Saved to report_output/report_{today}.pdf")

# --- Dashboard ---
def show_dashboard():
    today = str(date.today())
    focused = distracted = 0
    entries = 0

    with open(LOG_FILE, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if today in row['timestamp']:
                focused += int(row['focused_time'])
                distracted += int(row['distracted_time'])
                entries += 1

    total = focused + distracted
    percent = int((focused / total) * 100) if total else 0

    plt.figure(figsize=(10, 6), facecolor='#1e1e1e')
    plt.suptitle("FocusCam Daily Dashboard", color='white', fontsize=18)

    ax1 = plt.subplot2grid((2, 2), (0, 0))
    ax1.bar(['Focused', 'Distracted'], [focused, distracted], color=['#00ffcc', '#ff0055'], edgecolor='white')
    ax1.set_title("Time Distribution", color='white')
    ax1.set_facecolor('#2e2e2e')
    ax1.tick_params(colors='white')
    for i, v in enumerate([focused, distracted]):
        ax1.text(i, v + 1, str(v), color='white', ha='center')

    ax2 = plt.subplot2grid((2, 2), (0, 1))
    ax2.pie([focused, distracted], labels=['Focused', 'Distracted'], autopct='%1.1f%%', colors=['#00ffcc', '#ff0055'], startangle=140, textprops={'color': 'white'})
    ax2.set_title("Focus Ratio", color='white')

    ax3 = plt.subplot2grid((2, 2), (1, 0), colspan=2)
    quote = get_quote(percent)
    ax3.text(0.5, 0.5, f"""Today's Focus: {percent}%
Total Sessions: {entries}
Focused Time: {timedelta(seconds=focused)}
Distracted Time: {timedelta(seconds=distracted)}

{quote}""",
             ha='center', va='center', fontsize=14, color='#00ffcc', wrap=True)
    ax3.axis('off')
    ax3.set_facecolor('#2e2e2e')

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()

# --- Quote Editor ---
def open_quote_editor():
    editor = tk.Toplevel()
    editor.title("Edit Quotes")

    def refresh():
        listbox.delete(0, tk.END)
        for q in quotes[category.get()]:
            listbox.insert(tk.END, q)

    def add():
        q = simpledialog.askstring("Add Quote", "Enter quote:")
        if q:
            quotes[category.get()].append(q)
            save_quotes(quotes)
            refresh()

    def delete():
        sel = listbox.curselection()
        if sel:
            quotes[category.get()].pop(sel[0])
            save_quotes(quotes)
            refresh()

    category = tk.StringVar(value="motivational")
    tk.Radiobutton(editor, text="Motivational", variable=category, value="motivational", command=refresh).pack()
    tk.Radiobutton(editor, text="Punishing", variable=category, value="punishing", command=refresh).pack()

    listbox = tk.Listbox(editor, width=50)
    listbox.pack(padx=10, pady=10)

    tk.Button(editor, text="Add", command=add).pack(side="left", padx=10)
    tk.Button(editor, text="Delete", command=delete).pack(side="left", padx=10)
    refresh()

# --- Session Logic ---
def run_focuscam_session(duration_minutes=30):
    global apply_night_mode
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1)
    cap = cv2.VideoCapture(0)

    session_start = time.time()
    session_duration = duration_minutes * 60
    focused_time = distracted_time = 0
    last_alert = 0
    last_break = session_start
    paused = False
    pause_start = 0
    total_pause = 0

    file_exists = os.path.isfile(LOG_FILE)
    with open(LOG_FILE, mode='a', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=['timestamp', 'elapsed_seconds', 'focused_time', 'distracted_time', 'focus_percent', 'paused'])
        if not file_exists:
            writer.writeheader()

        while True:
            now = time.time()
            elapsed = now - session_start - total_pause
            if elapsed >= session_duration:
                break

            ret, frame = cap.read()
            if not ret:
                break

            if apply_night_mode:
                frame = cv2.convertScaleAbs(frame, alpha=1.5, beta=30)

            if paused:
                if cv2.waitKey(1) & 0xFF == ord('p'):
                    paused = False
                    total_pause += time.time() - pause_start
                continue

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(rgb)
            focused = False

            if results.multi_face_landmarks:
                face = results.multi_face_landmarks[0]
                nose, chin = face.landmark[1], face.landmark[152]
                left_eye, right_eye = face.landmark[33], face.landmark[263]
                pitch = calculate_head_pitch(nose, chin)
                eyes_up = left_eye.y < chin.y and right_eye.y < chin.y
                focused = (-10 <= pitch <= 70) and eyes_up

            if focused:
                focused_time += 1
            else:
                distracted_time += 1
                if time.time() - last_alert > 5:
                    play_alert_sound()
                    speak("Please focus.")
                    save_snapshot(frame)
                    last_alert = time.time()

            if (now - last_break) > BREAK_INTERVAL_MINUTES * 60:
                speak("Time for a short break")
                time.sleep(BREAK_DURATION_SECONDS)
                last_break = time.time()

            total = focused_time + distracted_time
            percent = int((focused_time / total) * 100) if total else 0
            quote = get_quote(percent)
            cv2.putText(frame, quote, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

            cv2.imshow("FocusCam", frame)
            writer.writerow({
                'timestamp': datetime.now().isoformat(),
                'elapsed_seconds': int(elapsed),
                'focused_time': focused_time,
                'distracted_time': distracted_time,
                'focus_percent': percent,
                'paused': paused
            })

            key = cv2.waitKey(1) & 0xFF
            if key == ord('p'):
                paused = True
                pause_start = time.time()
            elif key == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

# --- GUI ---
app = tk.Tk()
app.title("FocusCam Study Timer")
style = ttk.Style(app)

apply_night_mode = False
night_mode = tk.BooleanVar(value=False)

def toggle_dark_mode():
    style.theme_use("clam" if app.tk.call("ttk::style", "theme", "use") == "default" else "default")

def toggle_night_mode():
    global apply_night_mode
    apply_night_mode = night_mode.get()

label = ttk.Label(app, text="Enter study duration (minutes):")
label.pack(padx=10, pady=5)
entry = ttk.Entry(app)
entry.pack(padx=10, pady=5)

start_btn = ttk.Button(app, text="Start Session", command=lambda: threading.Thread(target=run_focuscam_session, args=(int(entry.get()),), daemon=True).start())
start_btn.pack(pady=5)

dash_btn = ttk.Button(app, text="View Dashboard", command=show_dashboard)
dash_btn.pack(pady=5)

quote_btn = ttk.Button(app, text="Edit Quotes", command=open_quote_editor)
quote_btn.pack(pady=5)

pdf_btn = ttk.Button(app, text="Export PDF Report", command=generate_pdf_report)
pdf_btn.pack(pady=5)

dark_btn = ttk.Button(app, text="Toggle Dark Mode", command=toggle_dark_mode)
dark_btn.pack(pady=5)

night_check = ttk.Checkbutton(app, text="Enable Night Mode", variable=night_mode, command=toggle_night_mode)
night_check.pack(pady=5)

creator = ttk.Label(app, text="Created by: Bio Godfred | GitHub: Godfredsprim | WhatsApp: +233599966902" , font=("Segoe UI", 9))
creator.pack(pady=10)

app.mainloop()
